jQuery(function() {
    var $ = jQuery;
    // The Bot Images Slideshow
    $(".syb-gallery").slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
      });
})